using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spike : EnvironmentalHazard
{
    // When we want specific behavior for spikes
}
