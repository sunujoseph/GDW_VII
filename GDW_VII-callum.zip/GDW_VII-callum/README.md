# GDW_VII
 
